<!-- content @s -->
<div class="nk-content nk-content-fluid">
    <div class="container-xl wide-xl">
        <div class="nk-content-inner">
            <div class="nk-content-body">
                <div class="nk-block-head nk-block-head-sm">
                    <div class="nk-block-between">
                        <!-- .nk-block-head-content -->
                    </div><!-- .nk-block-between -->
                </div><!-- .nk-block-head -->
                <div class="nk-block">
                    <div class="row g-gs">
                        <div class="col-xl-12 col-xxl-8">
                            <div class="card card-bordered card-full">
                                <div class="card-inner border-bottom">
                                    <div class="card-title-group">
                                        <div class="card-title">
                                            <h6 class="title">Dashboard</h6>
                                        </div>
                                    </div>
                                </div>
                                <div class="container mt-5 mb-5">
                                    <p class="text-center">
                                        <img src="<?= base_url() ?>assets/logo_sukses_mandiri_dark.png" alt="unimal-logo" style="width: 200px;">
                                    </p>
                                    <h3 class="text-center">Aplikasi Gudang Sukses Mandiri</h3>
                                </div>
                            </div><!-- .card -->
                        </div><!-- .col -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- content @e -->