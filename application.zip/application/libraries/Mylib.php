<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mylib
{

	/*fungsi membuat menampilkan halaman tertentu*/
	// function dview($view, $data = array())
	// {
	// 	$ci = &get_instance();
	// 	if (!array_key_exists('title', $data)) {
	// 		$data['title'] = 'BKD - Beban Kerja Dosen Universitas Malikussaleh';
	// 	}
	// 	$data['menu'] = $ci->uri->segment(3);
	// 	$ci->load->view('dosen/template/v_header', $data);
	// 	$ci->load->view('dosen/template/v_navbar', $data);
	// 	if ($data) {
	// 		$ci->load->view('dosen/' . $view, $data);
	// 	} else {
	// 		$ci->load->view($view);
	// 	}
	// 	$ci->load->view('dosen/template/v_footer', $data);
	// }

	function aview($view, $data = array())
	{
		$ci = &get_instance();
		if (!array_key_exists('title', $data)) {
			$data['title'] = 'Sistem Gudang Sukses Mandiri';
		}
		if ($ci->session->userdata('status') === 'loginadmin') {
			$ci->load->view('admin/template/v_header', $data);
			$ci->load->view('admin/template/v_navbar', $data);
			if ($data) {
				$ci->load->view('page/' . $view, $data);
			} else {
				$ci->load->view($view);
			}
			$ci->load->view('admin/template/v_footer', $data);
		} elseif ($ci->session->userdata('status') === 'loginowner') {
			$ci->load->view('owner/template/v_header', $data);
			$ci->load->view('owner/template/v_navbar', $data);
			if ($data) {
				$ci->load->view('page/' . $view, $data);
			} else {
				$ci->load->view($view);
			}
			$ci->load->view('operator/template/v_footer', $data);
		} elseif ($ci->session->userdata('status') === 'loginopt') {
			$ci->load->view('operator/template/v_header', $data);
			$ci->load->view('operator/template/v_navbar', $data);
			if ($data) {
				$ci->load->view('page/' . $view, $data);
			} else {
				$ci->load->view($view);
			}
			$ci->load->view('operator/template/v_footer', $data);
		}
	}

	function autoCode($field_code, $initial = 'SMBRG', $tabel)
	{
		$ci = &get_instance();
		$ci->db->order_by($field_code, 'DESC');
		$res = $ci->db->get($tabel);
		$data = $res->row_array();
		if ($data) {
			$value = $data[$field_code];
			$result = substr($value, 4, 8);
			$result = (int)$result;
			$result = $result + 1;
			$coderesult = $initial . "-" . STR_PAD($result, 6, "0", STR_PAD_LEFT);
		} else {
			$coderesult = $initial . "-" . "000001";
		}
		return $coderesult;
	}
}
